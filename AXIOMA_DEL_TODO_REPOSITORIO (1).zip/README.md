# Axioma del Todo

Repositorio para organizar, compartir y validar mediciones reales de tiempo, luz y materia.
