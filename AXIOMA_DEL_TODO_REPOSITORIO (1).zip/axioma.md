## Axioma del Todo
Toda entidad real opera con { +, -, ×, ÷ } sobre magnitudes medibles: tiempo, luz o materia.