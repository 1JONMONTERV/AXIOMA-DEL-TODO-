## Experimento de la Gota
Una gota de agua curva la luz. El color observado en la hoja blanca representa fases del tiempo visible. El tiempo, la luz y la materia no son separables.